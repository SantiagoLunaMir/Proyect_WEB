// src/polyfills.ts
import 'zone.js';  // necesario para Angular
